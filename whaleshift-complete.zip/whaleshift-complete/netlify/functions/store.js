const crypto = require('crypto');
const { getStore } = require('@netlify/blobs');

const json = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { 'content-type': 'application/json', 'cache-control': 'no-store' }
});

function secret() {
  return process.env.ADMIN_SECRET || '';
}

function sign(payload) {
  const data = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', secret()).update(data).digest('base64url');
  return `${data}.${sig}`;
}

function verify(token) {
  if (!token || !secret()) return null;
  const [data, sig] = token.split('.');
  if (!data || !sig) return null;
  const expected = crypto.createHmac('sha256', secret()).update(data).digest('base64url');
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  try {
    const payload = JSON.parse(Buffer.from(data, 'base64url').toString());
    if (!payload.exp || payload.exp < Date.now()) return null;
    return payload;
  } catch { return null; }
}

function auth(request) {
  const h = request.headers.get('authorization') || '';
  return verify(h.startsWith('Bearer ') ? h.slice(7) : '');
}

const productsStore = () => getStore('whaleshift-products');
const imageStore = () => getStore('whaleshift-images');

export default async (request) => {
  const url = new URL(request.url);
  const action = url.searchParams.get('action') || 'products';

  try {
    if (action === 'login' && request.method === 'POST') {
      const { email, password } = await request.json();
      const ok = email === process.env.ADMIN_EMAIL && password === process.env.ADMIN_PASSWORD && secret();
      if (!ok) return json({ error: 'Invalid email or password' }, 401);
      const token = sign({ sub: email, exp: Date.now() + 1000 * 60 * 60 * 12 });
      return json({ success: true, token });
    }

    if (action === 'products' && request.method === 'GET') {
      const store = productsStore();
      const data = await store.get('catalog', { type: 'json' });
      return json(data || { watches: [], wallets: [] });
    }

    if (!auth(request)) return json({ error: 'Unauthorized' }, 401);

    if (action === 'products' && request.method === 'PUT') {
      const body = await request.json();
      const safe = {
        watches: Array.isArray(body.watches) ? body.watches : [],
        wallets: Array.isArray(body.wallets) ? body.wallets : []
      };
      await productsStore().setJSON('catalog', safe);
      return json({ success: true, data: safe });
    }

    if (action === 'products' && request.method === 'DELETE') {
      await productsStore().delete('catalog');
      return json({ success: true });
    }

    if (action === 'upload' && request.method === 'POST') {
      const body = await request.json();
      if (!body.name || !body.dataUrl) return json({ error: 'Image is required' }, 400);
      const match = String(body.dataUrl).match(/^data:(image\/(?:jpeg|png|webp|gif));base64,(.+)$/);
      if (!match) return json({ error: 'Only JPG, PNG, WEBP or GIF images are allowed' }, 400);
      const mime = match[1];
      const bytes = Buffer.from(match[2], 'base64');
      if (bytes.length > 5 * 1024 * 1024) return json({ error: 'Image must be 5MB or smaller' }, 400);
      const ext = mime.split('/')[1].replace('jpeg', 'jpg');
      const key = `${Date.now()}-${crypto.randomBytes(8).toString('hex')}.${ext}`;
      await imageStore().set(key, bytes, { metadata: { contentType: mime } });
      return json({ success: true, url: `/.netlify/functions/store?action=image&key=${encodeURIComponent(key)}` });
    }

    if (action === 'image' && request.method === 'GET') {
      const key = url.searchParams.get('key');
      if (!key) return new Response('Missing key', { status: 400 });
      const item = await imageStore().getWithMetadata(key, { type: 'arrayBuffer' });
      if (!item || !item.data) return new Response('Not found', { status: 404 });
      return new Response(item.data, {
        headers: {
          'content-type': item.metadata?.contentType || 'application/octet-stream',
          'cache-control': 'public, max-age=31536000, immutable'
        }
      });
    }

    return json({ error: 'Not found' }, 404);
  } catch (e) {
    return json({ error: e?.message || 'Server error' }, 500);
  }
};
